// src/scripts/twitter.js
(async () => {
  // Utility functions for getting and setting settings
  async function getSetting(key) {
    const result = await browser.storage.sync.get(key);
    return result[key];
  }

  async function setSetting(key, value) {
    await browser.storage.sync.set({ [key]: value });
  }

  // Debug logger
  let debugEnabled = (await getSetting("debug_enabled")) || false;
  function debugLog(...args) {
    if (debugEnabled) {
      console.log("[Twitter-DeepL]", ...args);
    }
  }

  debugLog("Extension script started");

  // Watch for new tweets
  function observeTweets() {
    debugLog("Initializing tweet observer");

    const tweetSelector = 'article[data-testid="tweet"]';

    // Initial processing of existing tweets
    document.querySelectorAll(tweetSelector).forEach((tweet) => {
      debugLog("Processing existing tweet");
      processTweet(tweet);
    });

    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.matches(tweetSelector)) {
              debugLog("New tweet detected directly");
              processTweet(node);
            } else {
              node.querySelectorAll(tweetSelector).forEach((tweet) => {
                debugLog("New tweet detected within added node");
                processTweet(tweet);
              });
            }
          }
        });
      });
    });

    observer.observe(document.body, { childList: true, subtree: true });
    debugLog("Tweet observer initialized");
  }

  // Process a single tweet
  async function processTweet(tweetElement) {
    try {
      // Check if the translate button exists
      const translateButtonSpan = tweetElement.querySelector(
        'button[role="button"][type="button"] > span'
      );

      if (
        translateButtonSpan &&
        translateButtonSpan.innerText === "Translate post"
      ) {
        debugLog("Translate button found");

        // Create new DeepL translate button
        const deepLButton = createDeepLButton();

        // Replace the existing button
        const parentButton = translateButtonSpan.closest("button");
        parentButton.parentNode.replaceChild(deepLButton, parentButton);

        // Initialize storage for original and translated texts
        let isTranslated = false;
        let originalText = null;
        let translatedText = null;

        // Get the tweet text element
        const tweetTextElement = tweetElement.querySelector(
          'div[data-testid="tweetText"]'
        );

        // Attach event listener to the DeepL button
        deepLButton.addEventListener("click", async () => {
          debugLog("DeepL translate button clicked");

          if (!tweetTextElement) {
            debugLog("Tweet text element not found");
            return;
          }

          // If already translated, revert to original text
          if (isTranslated) {
            tweetTextElement.innerText = originalText;
            isTranslated = false;
            deepLButton.querySelector("span").innerText =
              "Translate with DeepL";
            debugLog("Reverted to original text");
          } else {
            // If translation not yet done, translate and cache
            if (!translatedText) {
              // Fetch API key and settings
              const apiKey = await getSetting("api_key");
              const targetLanguage =
                (await getSetting("target_language")) || "EN-US";
              const formality = (await getSetting("formality")) || "default";
              const splitSentences = (await getSetting("split_sentences"))
                ? 1
                : 0;
              const preserveFormatting = (await getSetting(
                "preserve_formatting"
              ))
                ? 1
                : 0;

              if (!apiKey) {
                alert(
                  "Please set your DeepL API Key in the extension options."
                );
                return;
              }

              // Get the tweet text
              originalText = tweetTextElement.innerText;
              debugLog("Original tweet text:", originalText);

              // Translate the text
              try {
                translatedText = await translateText(
                  originalText,
                  apiKey,
                  targetLanguage,
                  formality,
                  splitSentences,
                  preserveFormatting
                );
                debugLog("Translated text:", translatedText);
              } catch (error) {
                debugLog("Error during translation:", error);
                alert("An error occurred while translating the tweet.");
                return;
              }
            }

            // Update the tweet text
            tweetTextElement.innerText = translatedText;
            isTranslated = true;
            deepLButton.querySelector("span").innerText = "Show Original";
            debugLog("Displayed translated text");
          }
        });

        // Add hover event to show tooltip with the other text
        tweetElement.addEventListener("mouseenter", () => {
          if (isTranslated) {
            tweetTextElement.title = originalText;
          } else if (translatedText) {
            tweetTextElement.title = translatedText;
          }
        });

        tweetElement.addEventListener("mouseleave", () => {
          tweetTextElement.removeAttribute("title");
        });
      } else {
        debugLog("Translate button not found in this tweet");
      }
    } catch (error) {
      debugLog("Error in processTweet:", error);
    }
  }

  // Create the DeepL translate button
  function createDeepLButton() {
    debugLog("Creating DeepL translate button");

    const button = document.createElement("button");
    button.setAttribute("role", "button");
    button.setAttribute("type", "button");
    button.style.color = "rgb(0, 186, 124)";
    button.style.cursor = "pointer";
    button.style.background = "none";
    button.style.border = "none";
    button.style.padding = "0";
    button.style.font = "inherit";

    const span = document.createElement("span");
    span.innerText = "Translate with DeepL";
    span.style.fontFamily =
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
    span.style.fontSize = "15px";
    span.style.lineHeight = "20px";
    span.style.overflowWrap = "break-word";
    span.style.minWidth = "0px";
    span.style.maxWidth = "100%";

    // Add hover effect
    button.addEventListener("mouseover", () => {
      span.style.textDecoration = "underline";
    });
    button.addEventListener("mouseout", () => {
      span.style.textDecoration = "none";
    });

    button.appendChild(span);

    return button;
  }

  // Translate text using DeepL API
  async function translateText(
    text,
    apiKey,
    targetLanguage,
    formality,
    splitSentences,
    preserveFormatting
  ) {
    debugLog("Translating text with DeepL API");

    const url = apiKey
      ? "https://api-free.deepl.com/v2/translate"
      : "https://api.deepl.com/v2/translate";

    const params = new URLSearchParams();
    params.append("auth_key", apiKey);
    params.append("text", text);
    params.append("target_lang", targetLanguage);
    params.append("formality", formality);
    params.append("split_sentences", splitSentences);
    params.append("preserve_formatting", preserveFormatting);

    debugLog("Sending request to DeepL API");

    const response = await fetch(url, {
      method: "POST",
      body: params,
    });

    const data = await response.json();

    if (response.ok) {
      debugLog("Received successful response from DeepL API");
      return data.translations[0].text;
    } else {
      debugLog("DeepL API returned an error:", data);
      throw new Error(data.message || "Translation failed");
    }
  }

  // Initialize the script
  observeTweets();
})();
