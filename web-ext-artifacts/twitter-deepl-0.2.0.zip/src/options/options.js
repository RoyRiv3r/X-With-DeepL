// src/options/options.js
import { getSetting, setSetting } from "../utils/storage.js";

document.addEventListener("DOMContentLoaded", async () => {
  const apiKeyInput = document.getElementById("api-key");
  const targetLanguageSelect = document.getElementById("target-language");
  const formalitySelect = document.getElementById("formality");
  const splitSentencesCheckbox = document.getElementById("split-sentences");
  const preserveFormattingCheckbox = document.getElementById(
    "preserve-formatting"
  );
  const debugEnabledCheckbox = document.getElementById("debug-enabled");

  // Load settings
  const apiKey = await getSetting("api_key");
  const targetLanguage = (await getSetting("target_language")) || "EN-US";
  const formality = (await getSetting("formality")) || "default";
  const splitSentences = (await getSetting("split_sentences")) !== false;
  const preserveFormatting = (await getSetting("preserve_formatting")) || false;
  const debugEnabled = (await getSetting("debug_enabled")) || false;

  apiKeyInput.value = apiKey || "";
  targetLanguageSelect.value = targetLanguage;
  formalitySelect.value = formality;
  splitSentencesCheckbox.checked = splitSentences;
  preserveFormattingCheckbox.checked = preserveFormatting;
  debugEnabledCheckbox.checked = debugEnabled;

  // Save settings
  document
    .getElementById("options-form")
    .addEventListener("submit", async (e) => {
      e.preventDefault();
      await setSetting("api_key", apiKeyInput.value);
      await setSetting("target_language", targetLanguageSelect.value);
      await setSetting("formality", formalitySelect.value);
      await setSetting("split_sentences", splitSentencesCheckbox.checked);
      await setSetting(
        "preserve_formatting",
        preserveFormattingCheckbox.checked
      );
      await setSetting("debug_enabled", debugEnabledCheckbox.checked);
      alert("Options saved.");
    });
});
