// src/utils/storage.js

// Utility functions for getting and setting settings
export async function getSetting(key) {
  const result = await browser.storage.sync.get(key);
  return result[key];
}

export async function setSetting(key, value) {
  await browser.storage.sync.set({ [key]: value });
}
