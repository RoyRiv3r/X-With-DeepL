// src/scripts/twitter.js

const { getSetting } = require("../utils/storage.js");
const { debugLog } = require("../utils/logger.js");
const { DeepLTranslator } = require("../translator/translator.js");

(async () => {
  debugLog("Extension script started");

  const translationState = new WeakMap();
  let observer;

  // Start observing tweets and notes
  observeContent();

  /**
   * Initializes the MutationObserver to monitor tweets and notes.
   */
  function observeContent() {
    debugLog("Initializing observer for tweets and notes");

    const tweetTextSelector = 'div[data-testid="tweetText"]';
    const noteTextSelector = [
      // Notes on the tweet's page (/status/)
      'div[data-testid="birdwatch-pivot"] > div[dir="ltr"].css-146c3p1',
      // Notes on the /i/birdwatch/ page
      'div.css-175oi2r.r-1471scf.r-18u37iz.r-iphfwy.r-1h8ys4a > div[dir="ltr"].css-146c3p1',
    ].join(", ");

    // Process existing tweets and notes
    document
      .querySelectorAll(`${tweetTextSelector}, ${noteTextSelector}`)
      .forEach(processTextElement);

    observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType !== Node.ELEMENT_NODE) return;

          // Remove "Translate post" button if it appears
          if (isTranslatePostButton(node)) {
            node.remove();
          }

          // Process tweets and notes
          if (node.matches(tweetTextSelector) || isNoteTextElement(node)) {
            processTextElement(node);
          }

          // Process nested elements
          node
            .querySelectorAll(
              `${tweetTextSelector}:not([data-deepl-processed]), ${noteTextSelector}:not([data-deepl-processed])`
            )
            .forEach(processTextElement);

          // Remove "Translate post" buttons inside nested elements
          node.querySelectorAll('button[role="button"]').forEach((button) => {
            if (isTranslatePostButton(button)) {
              button.remove();
            }
          });
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  /**
   * Processes a text element (tweet or note) by adding the translate button.
   * @param {HTMLElement} textElement - The tweet or note text element.
   */
  function processTextElement(textElement) {
    if (textElement.dataset.deeplProcessed) return;

    const isNote = isNoteTextElement(textElement);
    const container = findContainerElement(textElement, isNote);

    if (!container) {
      debugLog("Container element not found");
      return;
    }

    translationState.set(textElement, {
      isTranslated: false,
      originalText: null,
      translatedText: null,
    });

    textElement.dataset.deeplProcessed = "true";

    removeExistingTranslateButtons(container);
    removeTwitterTranslateButton(container); // Remove Twitter's "Translate post" button

    let translateButton;
    if (isNote) {
      translateButton = createTranslateNoteButton();
    } else {
      translateButton = createTranslateTweetButton();
    }

    insertTranslateButton(textElement, translateButton, isNote);

    translateButton.addEventListener("click", async () => {
      await handleTranslateButtonClick(textElement, translateButton);
    });
  }

  /**
   * Checks if an element is a note text element.
   * @param {HTMLElement} element - The DOM element to check.
   * @returns {boolean} True if the element is a note text element.
   */
  function isNoteTextElement(element) {
    return (
      // Note on the tweet's page (/status/)
      (element.matches('div[dir="ltr"].css-146c3p1') &&
        element.parentElement &&
        element.parentElement.matches('div[data-testid="birdwatch-pivot"]')) ||
      // Notes on the /i/birdwatch/ page
      (element.matches('div[dir="ltr"].css-146c3p1') &&
        element.parentElement &&
        element.parentElement.matches(
          "div.css-175oi2r.r-1471scf.r-18u37iz.r-iphfwy.r-1h8ys4a"
        ))
    );
  }

  /**
   * Finds the container element for a text element.
   * @param {HTMLElement} textElement - The text element.
   * @param {boolean} isNote - Whether the text element is a note.
   * @returns {HTMLElement|null} The container element or null if not found.
   */
  function findContainerElement(textElement, isNote) {
    if (isNote) {
      if (window.location.pathname.startsWith("/i/birdwatch")) {
        return textElement.closest(
          "div.css-175oi2r.r-1471scf.r-18u37iz.r-iphfwy.r-1h8ys4a"
        );
      } else {
        return textElement.closest('div[data-testid="birdwatch-pivot"]');
      }
    } else {
      return textElement.closest(
        'article[data-testid="tweet"], div[data-testid="tweet"], div[role="article"], div'
      );
    }
  }

  /**
   * Removes existing translate buttons from a container.
   * @param {HTMLElement} container - The container element.
   */
  function removeExistingTranslateButtons(container) {
    const translateButtons = container.querySelectorAll(
      "button.deepl-translate-button"
    );
    translateButtons.forEach((button) => {
      // Remove the button's container div
      if (button.parentElement) {
        button.parentElement.remove();
      } else {
        button.remove();
      }
    });
  }

  function removeTwitterTranslateButton(container) {
    const translateButtons = container.querySelectorAll(
      'button[role="button"]'
    );
    translateButtons.forEach((button) => {
      const span = button.querySelector("span");
      if (span && span.innerText.trim() === "Translate post") {
        button.remove();
      }
    });
  }

  function isTranslatePostButton(element) {
    if (element.tagName !== "BUTTON") return false;
    if (element.getAttribute("role") !== "button") return false;
    const span = element.querySelector("span");
    return span && span.innerText.trim() === "Translate post";
  }

  /**
   * Inserts the translate button into the DOM.
   * @param {HTMLElement} textElement - The text element.
   * @param {HTMLElement} translateButton - The translate button element.
   * @param {boolean} isNote - Whether the text element is a note.
   */
  function insertTranslateButton(textElement, translateButton, isNote) {
    const buttonContainer = document.createElement("div");
    buttonContainer.style.display = "inline-block";
    buttonContainer.style.width = "auto";
    buttonContainer.style.marginTop = "8px";
    buttonContainer.appendChild(translateButton);

    if (isNote && window.location.pathname.startsWith("/i/birdwatch")) {
      const container = findContainerElement(textElement, true);
      container.appendChild(buttonContainer);
    } else {
      const parentNode = textElement.parentNode;

      // Try to find the "Show more" link that follows the textElement
      const showMoreLink = parentNode.querySelector(
        '[data-testid="tweet-text-show-more-link"]'
      );

      if (showMoreLink) {
        // Insert after the "Show more" link
        parentNode.insertBefore(buttonContainer, showMoreLink.nextSibling);
      } else {
        // Insert after the text element
        parentNode.insertBefore(buttonContainer, textElement.nextSibling);
      }
    }
  }

  /**
   * Handles the click event on the translate button.
   * @param {HTMLElement} textElement - The text element.
   * @param {HTMLElement} translateButton - The translate button element.
   */
  async function handleTranslateButtonClick(textElement, translateButton) {
    try {
      const state = translationState.get(textElement);
      if (!state) {
        debugLog("No translation state found for this text element");
        return;
      }

      if (state.isTranslated) {
        restoreOriginalText(textElement, state);
        state.isTranslated = false;
        updateButtonText(translateButton, false);
      } else {
        if (!state.translatedText) {
          const apiKey = await getSetting("api_key");
          if (!apiKey) {
            alert("Please set your DeepL API Key in the extension options.");
            return;
          }

          const translator = new DeepLTranslator(apiKey);
          const targetLanguage =
            (await getSetting("target_language")) || "EN-US";
          const formality = (await getSetting("formality")) || "default";
          const splitSentences = (await getSetting("split_sentences")) ? 1 : 0;
          const preserveFormatting = (await getSetting("preserve_formatting"))
            ? 1
            : 0;

          state.originalText = textElement.innerHTML;

          try {
            state.translatedText = await translator.translateText(
              state.originalText,
              {
                targetLanguage,
                formality,
                splitSentences,
                preserveFormatting,
              }
            );
          } catch (error) {
            alert(
              `An error occurred while translating the text: ${error.message}`
            );
            return;
          }
        }

        updateTextWithTranslation(textElement, state.translatedText);
        state.isTranslated = true;
        updateButtonText(translateButton, true);
      }
    } catch (error) {
      debugLog("Error in handleTranslateButtonClick:", error);
    }
  }

  /**
   * Updates the button text based on translation state.
   * @param {HTMLElement} button - The translate button element.
   * @param {boolean} isTranslated - Whether the text is currently translated.
   */
  function updateButtonText(button, isTranslated) {
    const span = button.querySelector("span");
    if (isTranslated) {
      span.innerText = "Show Original";
    } else {
      span.innerText = button.dataset.originalText;
    }
  }

  /**
   * Restores the original text of the text element.
   * @param {HTMLElement} textElement - The text element.
   * @param {Object} state - The translation state.
   */
  function restoreOriginalText(textElement, state) {
    textElement.innerHTML = state.originalText;
  }

  /**
   * Updates the text element with the translated text.
   * @param {HTMLElement} textElement - The text element.
   * @param {string} translatedHtml - The translated HTML content.
   */
  function updateTextWithTranslation(textElement, translatedHtml) {
    textElement.innerHTML = translatedHtml;
  }

  /**
   * Creates a translate button for tweets.
   * @returns {HTMLElement} The translate button element.
   */
  function createTranslateTweetButton() {
    const buttonText = "Translate with DeepL";
    const button = document.createElement("button");
    button.setAttribute("type", "button");
    button.classList.add("deepl-translate-button");
    button.dataset.originalText = buttonText;
    applyButtonStyles(button);

    const span = document.createElement("span");
    span.innerText = buttonText;
    applySpanStyles(span);

    button.appendChild(span);

    return button;
  }

  /**
   * Creates a translate button for notes with a line break.
   * @returns {HTMLElement} The container element with the translate button and line break.
   */
  function createTranslateNoteButton() {
    const buttonText = "Translate note with DeepL";
    const button = document.createElement("button");
    button.setAttribute("type", "button");
    button.classList.add("deepl-translate-button");
    button.dataset.originalText = buttonText;
    applyButtonStyles(button);

    const span = document.createElement("span");
    span.innerText = buttonText;
    applySpanStylesNote(span);

    button.appendChild(span);

    // Create a container for the button and line break
    const container = document.createElement("div");
    container.appendChild(button);

    // Add a line break after the button
    const lineBreak = document.createElement("br");
    container.appendChild(lineBreak);

    return container;
  }

  /**
   * Applies common styles to the translate button element.
   * @param {HTMLElement} button - The button element.
   */
  function applyButtonStyles(button) {
    button.style.display = "inline-flex";
    button.style.alignItems = "center";
    button.style.cursor = "pointer";
    button.style.background = "none";
    button.style.border = "none";
    button.style.padding = "0";
    button.style.margin = "0";
    button.style.font = "inherit";
    button.style.verticalAlign = "baseline";
    button.style.width = "auto";
    button.style.maxWidth = "none";
    button.style.flexShrink = "0";
    button.style.alignSelf = "flex-start";
    button.style.color = "rgb(29, 155, 240)";

    button.addEventListener("mouseover", () => {
      const span = button.querySelector("span");
      span.style.textDecoration = "underline";
    });
    button.addEventListener("mouseout", () => {
      const span = button.querySelector("span");
      span.style.textDecoration = "none";
    });
  }

  /**
   * Applies common styles to the span element inside the button.
   * @param {HTMLElement} span - The span element.
   */
  function applySpanStyles(span) {
    span.style.fontFamily =
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
    span.style.fontSize = "15px";
    span.style.lineHeight = "20px";
    span.style.textDecoration = "none";
  }

  /**
   * Applies common styles to the span NOTE element inside the button.
   * @param {HTMLElement} span - The span element.
   */
  function applySpanStylesNote(span) {
    span.style.fontFamily =
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
    span.style.fontSize = "15px";
    span.style.lineHeight = "20px";
    span.style.textDecoration = "none";
    span.style.marginLeft = "10px";
  }
})();
